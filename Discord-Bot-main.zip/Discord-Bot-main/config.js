module.exports = {
    "cooldowns": {
      "daily": 86400,
      "beg": 300,
      "lootbox": 432000, // 5 days
      "work": 3600, // 1 hour
      "rob": 1800 // 30 minutes
    }
};
